import React, { useState, useEffect } from "react";
import { connect, styled, keyframes } from "frontity";
import Triangle from "../../img/triangle_graphic1-01.svg";
import ArrowDown from "../../img/icon_down-arrowRed.svg";

const Img = Triangle;
const downArrow = ArrowDown;

function Intro(props){

  //console.log(props.data);

  const [mobile, setMobile] = useState(false);
  useEffect(()=>{
    if(typeof window !== "undefined"){
      setMobile(window.matchMedia('(max-width: 600px)').matches);
      $(window).on('resize',function(){
        setMobile(window.matchMedia('(max-width: 600px)').matches)
      });
    }
  }, []);

  return(
    <Section id="mainIntro" 
    data-smooth-scrolling="off" 
    bgTriangle={Img} 
    intoBg={props.data.background_image} 
    intoBgMobile={props.data.mobile_background_image}>

      {mobile ?

       <>
          <div className="animate__animated animate__fadeIn animate__delay-1s">
            <div className="obj1 control-animation animate__animated animate__fadeInUp animate__delay-2s"
            data-0="position:fixed; background-size: 170%;"
            data-400="position:fixed; background-size: 245%;"
            data-600="position:fixed; background-size: 322%;"
            data-800="position:fixed; background-size: 335%;"></div>

            <div className="obj2 control-animation"
            data-0="position:fixed; opacity:1;  background-size: 420%;"
            data-400="position:fixed; opacity:1; background-size: 550%;"
            data-600="position:fixed; opacity:1; background-size: 1000%;"
            data-800="position:fixed; opacity:1; background-size: 2640%;">
            </div>
          </div>
        </>

      :
        <>
          <div className="animate__animated animate__fadeIn animate__delay-1s">
           <div className="obj1 control-animation animate__animated animate__fadeInUp animate__delay-2s"
            data-0="background-size: 65%;"
            data-500="background-size: 100%;"
            data-600="background-size: 120%;"
            data-800="background-size: 130%;"
            data-950="background-size: 140%;"
            data-1050="background-size: 150%;"></div>

            <div className="obj2 control-animation"
            data-0="opacity:1;  background-size: 160%;"
            data-400="opacity:1; background-size: 300%;"
            data-600="opacity:1; background-size: 600%;"
            data-800="opacity:1; background-size: 1550%;"
            data-801="opacity:0;">
            </div>
          </div>
        </>
      }

      <div className="textObj">
        <div>
          <span className="animate__animated animate__fadeInUp animate__delay-2s"><img src={props.data.logo} /></span>
          <h1 className="animate__animated animate__fadeInUp animate__delay-2s" dangerouslySetInnerHTML={{ __html: props.data.headline }}></h1>
        </div>
      </div>

     <div className="scrollDown animate__animated animate__fadeIn animate__delay-3s">
       <span>SCROLL</span>
       <img src={downArrow} />
     </div>

    </Section>
  );
}


const Section = styled.section`
  position:relative; 
  overflow:hidden; 
  height:1800px;
  margin-bottom:0px;
  background:#ff0000;

  .obj1, .obj2{
    position: fixed;
    background-color: #000;
    margin: auto;
    left: 0;
    right: 0;
    top:0;
    bottom:0;
    width:100%;
    height:100%;
  }
  .obj1{
    background:#ff0000 url('${props => props.intoBg}') no-repeat center;
    background-size: 65%;
    z-index:1;
  }
  .obj2{
    background:url('${props => props.bgTriangle}') no-repeat center;
    border:0px solid #ff0000;
    background-size: 160%;
    /*background-position: center 65%;*/
    overflow:hidden;
    z-index:2;
  }
  
  .textObj{
    position: fixed;
    text-align:center;
    display:flex;
    justify-content: center;
    align-items: center;
    margin: auto;
    left: 0;
    right: 0;
    top:0;
    bottom:0;
    width:100%;
    height:100%;
    padding: 0 15px;
  }
  .textObj h1{
    font-weight: normal;
    color:#fff;
    margin-top:0;
    font-family: "Ginto Normal Regular";
    b{
      font-family: "Ginto Normal Bold";
    }
  }
  .textObj span{
    display:inline-block;
    width:300px;
    height:60px;    
    margin-top:150px;
    margin-bottom:20px;
  }
  .scrollDown{
    position: fixed;
    left: 0;
    right: 0;
    margin: auto;
    bottom: 25px;
    width: 80px;
    color:#fff;
    font-size:14px;
    font-family: "Ginto Nord Bold";
    text-align: center;
    cursor: pointer;
    display:block;
    img{
      margin:auto;
      margin-top: 20px;
      animation: bounceArrow 1s;
      animation-direction: alternate; 
      animation-timing-function: cubic-bezier(.5, 0.05, 1, 1); 
      animation-iteration-count: infinite;
    }
  }

  @media (max-width:767px){
    .obj1{
      background:#ff0000 url('${props => props.intoBgMobile}') no-repeat center;
      background-size: 170%;
    }
    .textObj span{
      width:200px;
      height:40px;
    }
    .scrollDown{
      font-size:12px;
      img{
        max-width:25px;
      }
    }
  }
`;

export default Intro;
