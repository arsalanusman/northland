import React from "react";
import { styled, connect } from "frontity";
import Link from "./link";
import SectionContainer from "./styles/section-container";
import globalStyle from "./styles/global-styles";


const Footer = ({ state }) => {
  const sidebar = state.source.get('sidebar');
  const getsidebar = sidebar.items['sidebar-1'];
  const color = state.theme.colors;
  //console.log(test);

    //console.log(getsidebar);

       return(
        <FooterSection bg={color.red}>
          <Container textColor={color.navy}>
              {getsidebar.map((items,index)=> {
                 if(items.type == 'nav_menu')
                return(  <List key={index}>
                    {items.value.map((nav,i)=>
                        <Item key={i}><ItemLink textColor={color.navy} link={'/'+nav.slug}>{nav.title}</ItemLink></Item>
                    )}
                  </List>
                )
                if(items.type == 'text')
                  return( 
                    <>
                      <span className="title">{items.instance.title}</span>
                      <div dangerouslySetInnerHTML={{ __html: items.instance.text }}></div>
                    </>
                  )
              })}
            </Container>
          </FooterSection>
        );
};

const FooterSection = styled.footer`
  position:relative;
	z-index:1;
  display:block;
  background:${props=>props.bg};
  font-family: "Ginto Normal Bold";
  padding: 100px 0 40px 0;
  text-align:center;
  .title{
    font-family: "Ginto Nord Bold";
    text-transform: uppercase;
    font-size:14px;
  }
  .flinks{
    font-family: "Ginto Normal Regular";
    font-size:14px;
    padding-top: 10px;
    a{
      padding:0 10px;
      &:hover{
        color:#fff;
      }
    }
  }
  .copyright{
    font-family: "Ginto Normal Regular";
    margin:auto;
    font-size:12px;
    border-top: 1px solid;
    padding: 20px 0 25px 0;
    margin-top: 45px;
    a{
      text-decoration: underline;
    }
  }

  @media (max-width:767px){
    padding: 40px 20px 20px 20px;
    ul{
      padding:0;
      margin-bottom: 20px;
      li{
        display:block;
        border-bottom:1px solid;
        a{
          padding:15px 0;
          display:inline-block;
        }
        &:last-child{
          border-bottom:0;
        }
        &:after{
          display:none;
        }
      }
    }
    .copyright{
      margin-top: 28px;
    }
  }

`;
const Container = styled.div`
  max-width:1290px;
  margin:auto;
  padding:0 15px;
  color:${props=>props.textColor};
  a{
    color:${props=>props.textColor};
  }
`;
const List = styled.ul`
  margin: 0;
  list-style: none;
  text-align: center;
  font-size: 14px;
  display:block;
  border-top:2px solid;
  border-bottom:1px solid;
  padding:12px 0 18px 0;
  margin-bottom: 40px;
`;
const Item = styled.li`
  display:inline-block;
  &:after{
    content:' | ';
    display: inline-block;
    padding: 0 16px;
  }
  &:last-child{
    &:after{
      content:'';
      display:none;
    }
  }
`;
const ItemLink = styled(Link)`
  color:${props=>props.textColor};
  &:hover{
    color:#fff;
  }
`;



export default connect(Footer);
