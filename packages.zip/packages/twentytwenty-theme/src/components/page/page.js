import React from "react";
import { connect, fetch } from "frontity";

const Frontpage = ({ state }) => {
  return(
    <h1>Test</h1>
  )
};

export default connect(Frontpage);
