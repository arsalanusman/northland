import React, { useRef } from "react";
import { styled, connect, Global } from "frontity";
import Link from "../link";
import Navigation from "../navigation/navigation";
import ButtonLink from "../styles/button"

const MobileMenuModal = ({ state }) => {
  const menu = state.source.get('menus');
  //console.log(menu, 'MY MENU');
  return (
    <Modal id="mobileModal">
      <ModalContainer>
        <div className="bottom">
          <ul className="primaryMenu">
            {menu.items.primary.map((nav, index) => {
              return (
                  <li key={index}><a href={'/'+ nav.parent.slug}>{nav.parent.title}</a></li>
              )
            })}
          </ul>
          <ul className="secondryMenu">
            {menu.items.footer.map((nav, index) => {
              return (
                  <li key={index}><a href={'/'+ nav.parent.slug}>{nav.parent.title}</a></li>
              )
            })}
          </ul>
          {menu.items.primary.map((nav, index) => {
              return (
                  <>
                    {nav.parent.type == 'custom' ? <ButtonLink href={'/'+ nav.parent.slug} color={'blue'}>{nav.parent.title}</ButtonLink> : <a href={'/'+ nav.parent.slug}>{nav.parent.title}</a>}
                  </>
              )
          })}
        </div>
      </ModalContainer>
    </Modal>
  );

};

const Modal = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: #ff0000;
  z-index: 10;
  display: none;
  @media (min-width:1023px){
    display:none;
  }
`;
const ModalContainer = styled.div`
  padding:0 25px;
  width: auto;
  margin-top: 60px;
  border-top: 1px solid;
  margin-left: 15px;
  margin-right: 15px;
  height: 90%;
  overflow: auto;
  ul{
    margin:0;
    list-style:none;
    color:#01203F;
    li{
      border-bottom:1px solid;
      a{
        color:#01203F;
        display:block;
        padding:15px 0;
      }
    }
  }

  ul.primaryMenu{
    li{
      font-size:24px;
      line-height:24px;
      font-family: "Ginto Nord Bold";
      letter-spacing: -0.5px;
    }
  }
  ul.secondryMenu{
    margin-bottom: 80px;
    li{
      font-size:16px;
      line-height:24px;
      font-family: "Ginto Normal Regular";
    }
  }

  .bottom{
    width:100%;
    padding-bottom:40px;
    padding-top: 30%;
    > a{
      display:block;
      button{
        width:100%;
        margin-top:10px;
      }
    }
  }

`;

export default connect(MobileMenuModal);
